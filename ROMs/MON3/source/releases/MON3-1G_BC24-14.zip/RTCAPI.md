# RTC API Calls
This API interacts with the DS1302 Real Time Clock chip, found on the RTC GPIO Board for the TEC-1G. The RTC chip is designed to respond on port $FCh.

The DS1302 supports 12 and 24 hour clock modes, a 100 year calendar (2000-2099) with leap year support, and 31 bytes of general purpose nonvolatile RAM.

Note that in addition to the C register calling the RTC API itself, the B register also specifies which RTC API function is required. In this way, all RTC functions only occupy a single MON3 API call.

## RTC API Calls List

| B Register | Call |
| :--: | --------- |
| 00 | checkDS1302Present |
| 01 | resetDS1302 |
| 02 | getTime |
| 03 | setTime |
| 04 | getDate |
| 05 | setDate |
| 06 | getDay |
| 07 | setDay |
| 08 | get1224Mode |
| 09 | set12HrMode |
| 10 | set24HrMode |
| 11 | readRTCByte |
| 12 | writeRTCByte |
| 13 | burstRTCRead |
| 14 | bcdToBin |
| 15 | binToBcd |
| 16 | formatTime |
| 17 | formatDate |

## changelog

### 1.1
Converted years to 2000..2099 & returned as BCD; needed to support leap years properly. BCD is easier to display and process, compared to decimal.

Added bintoBcd, bcdtoBin,  formatTime, formatDate API calls

###  1.0
Initial relese for testing

----

### checkDS1302Present #00
Check if a DS1302 is detectble, by verifying that the DS1302's registers return expected results.

Input:  
        nothing  

Return:
        CF set - no RTC  
        CF unset - RTC Present  

Destroy:
        A

### resetDS1302 #01
Resets the DS1302 to a known state - clears existing Time and Calendar. Does not clear RTC RAM.

Sets DS1302 to 01:00.00 AM, 01/01/2000

Input:  
        nothing  

Return:  
        none  

Destroy:  
        none  

** To be used *only* when the RTC requires a setings reset e.g. if it's not "ticking". Use checkDS1302Present to "reset" the DS1302 to a ready state, as part of program initialization.

### getTime #02
Get time from RTC. Time is formatted either 12 or 24 hour mode, depending on selected mode.

Input:  
        nothing  

Return:
        H = hour      ; bit 5 = am/pm flag (in 12 hr mode). 1=PM  
        L = minute  
        D = second  

Destroy:  
        A  

Note that all returned registers are BCD coded, so 10:24:36 results in HL=1024h, D=36h

### setTime #03
Sets the time in the RTC chip. Time is formatted either 12 or 24 hour mode, depending on selected mode.

Input:
        H = hour      ; bit 5 = am/pm flag (in 12 hr mode). 1=PM  
        L = minute  
        D = second  

Return:
        nothing  

Destroy:  
        A, E  

The 12/24 hour mode flag is preserved.

Note that all registers are BCD coded, so 10:24:36 is formatted as HL=1024h, D=36h

### getDate #04
Returns the present Calendar date, month, year.

Input:  
        nothing  

Return:  
        H - date  
        L - month  
        DE - year

Destroy:  
        A  

Note that values returned are BCD coded.

### setDate #05
Sets the Calendar to a specified date/month/year.

Note that invalid dates may be accepted e.g. **30 February** as the DS1302 does not validate dates as programmed; it simply rolls over at midnight.

Input:  
        H - date  
        L - month  
        DE - year 2000-2099* - note that D is ignored and assumed to be 20h  

Return:
        nothing

Destroy:  
        A  

Note that values returned are BCD coded.


### getDay #06
Gets the Day of the week i.e. "Monday", "Tuesday", etc. 01 = Monday, 07 = Sunday.

Input:  
        nothing  

Return:  
        D register: 01-07  
        HL Register: Returns as a pointer to an ASCIIZ string that providies the name of day of the week. e.g. .db "Monday",0

Destroy:  
        A  

The names of the days of the week are stored in the MON3 ROM; HL points to the correct string for that day.

### setDay #07
Sets the Day of the week. 01 = Monday, 07 = Sunday.

Input:  
        D register: 01-07  

Return:  
        CF set if an invalid value supplied.  

Destroy:  
        A  

### get1224Mode #08
Reports if the RTC is presently in 12 or 24 hour mode.

Input:  
        nothing  

Return:  
        A = 00h - 24 hour mode  
        A = 80h - 12 hour mode  

Destroy:  
        nothing  

### set12HrMode #09
Sets the RTC to 12 hour mode. That is, the hour is subsequently returned as 01-12, and an AM/PM flag.

Input:  
        nothing  

Return:  
        CF set - already in requested mode  
        CF clear - 12Hr mode set  

Destroy:  
        A, D

### set24HrMode #10
Sets the RTC to 24 hour mode (also known as Miliary Time). That is, the hour is subsequently returned as 00-23.

Input:  
        nothing  

Return:  
        CF set - already in requested mode  
        CF clear - 12Hr mode set  

Destroy:  
        A, D  

### readRTCByte #11
Reads a byte from the RTC RAM.

Input:  
        D - byte to return 0..30  

Return:  
        A - value read  

Destroy:  
       nothing  

### writeRTCByte #12
Writes a byte to the RTC RAM.

Input:  
        D - byte to write to 0..30  
        E - value to write  

Return:  
        none  

Destroy:  
        A  

### BurstRTCRead #13
Reads all 31 RTC RAM bytes and fills a user-supplied buffer with that data.

The user buffer should be 31 bytes long.

Input:  
        HL - location to write to (31 bytes to be written)  

Return:  
        HL - moves to next address after last byte  

Destroy:  
        A

### binToBcd #14
Converts the value in register A from BCD encoded, to binary. i.e. "23h" becomes "23" decimal.

Input:  
        A - BCD Value to convert

Return:  
        A - Binary equivalent Value

Destroy:  
        nothing

### BcdToBin #15
Converts the value in register A from binary to BCD. i.e. "52" decimal becomes "52h".

Input:  
        A - Binary Value to convert

Return:  
        A - BCD equivalent Value

Destroy:  
        nothing

### formatTime #16
Takes a time and fills a user-supplied buffer with an ASCIIZ string formatted as human-readable text.

The user-supplied buffer should be at least 12 bytes long.

bits 7 and 5 of the hour is used to format the time, if it is a 12hr mode timestamp - AM or PM is appended accordingly.

Input:  
        H = hour      ; bit 7 = 12/24hr, 1=12Hr mode. bit 5 = am/pm flag (in 12 hr mode), 1=PM  
        L = minute  
        D = second  
        IY = pointer to user supplied buffer  

Return:  
        IY - moves to next address after last byte  
Destroy:  
        A  

### formatDate #17
Takes a date and fills a user-supplied buffer with an ASCIIZ string formatted as human-readable text.

The user-supplied buffer should be at least 11 bytes long.

Dates are output as DD/MM/YYYY  

Input:  
        H = date  
        L = month  
        DE = year  
        IY = pointer to user supplied buffer  

Return:  
        IY - moves to next address after last byte  

Destroy:  
        A  

